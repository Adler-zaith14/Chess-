public enum Alliance {
  
}